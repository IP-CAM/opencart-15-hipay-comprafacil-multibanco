<?php
// Heading
$_['heading_title']      = 'Comprafacil';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Cash On Delivery payment module!';

// Entry
$_['entry_cf_username']        = 'Comprafacil Username';
$_['entry_cf_password'] = 'Comprafacil Password';
$_['entry_cf_mode']     = 'Comprafacil Test Mode';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Cash On Delivery!';
?>